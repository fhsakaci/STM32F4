RNDIS driver for STM32F4-discovery example (ver 1.1)

Demonstration video: http://www.youtube.com/watch?v=hsqWIqY8b6A

LRNDIS library supports:
- STMF4 MCU
- Any WEB browser
- OS Windows, Linux, Android, Mac
- RNDIS/DHCP/DNS/HTTP protocols

Library license: MIT
Author: Fetisov Sergey (fsenok@gmail.com)
HEX-file for stm32f4-Discovery: github.com/fetisov/lrndis/blob/master/ide/MDK-ARM/cpufw/cpufw.hex

See also:
http://habrahabr.ru/post/274663
http://habrahabr.ru/post/248097
http://www.youtube.com/watch?v=W_o0lPivqsA

Device web page address:
http://192.168.7.1
or
http://run.stm
